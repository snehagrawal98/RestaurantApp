//
//  FoodAppApp.swift
//  FoodApp
//
//  Created by SnehaAgrawal on 14/01/23.
//

import SwiftUI

@main
struct FoodAppApp: App {
    var body: some Scene {
        WindowGroup {
            TabViewPage()
        }
    }
}
